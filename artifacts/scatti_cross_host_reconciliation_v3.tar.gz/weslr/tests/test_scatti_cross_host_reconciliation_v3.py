#!/usr/bin/env python3
"""Integration tests for SCATTI cross-host reconciliation V3."""

import json
import subprocess
import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent


class TestScattiCrossHostReconciliationV3(unittest.TestCase):
    """Integration tests for the full V3 reconciliation."""

    @classmethod
    def setUpClass(cls):
        cls.v3_dir = REPO_ROOT / "data" / "scatti_candidates" / "cross_host_reconciliation_v3"
        cls.required_artifacts = [
            "transport_commit_verification_v3.json",
            "transport_path_collision_v3.json",
            "imported_assurance_test_results_v3.json",
            "ubuntu_scatti_artifact_inventory_v3.json",
            "materials_project_evidence_verification_v3.json",
            "mp_parent_experiment_reaudit_v3.json",
            "multilingual_search_verification_v3.json",
            "structure_and_chgnet_evidence_verification_v3.json",
            "scatti_evidence_ledger_v3.json",
            "scatti_implementation_inventory_v3.json",
            "verifier_results_v3.json",
        ]

    def test_all_artifacts_exist(self):
        for name in self.required_artifacts:
            path = self.v3_dir / name
            self.assertTrue(path.exists(), f"Missing: {name}")

    def test_all_json_valid(self):
        for name in self.required_artifacts:
            path = self.v3_dir / name
            if path.exists():
                with open(path) as f:
                    data = json.load(f)
                self.assertIsNotNone(data, f"Empty JSON: {name}")

    def test_transport_commit_verified(self):
        path = self.v3_dir / "transport_commit_verification_v3.json"
        with open(path) as f:
            data = json.load(f)
        self.assertEqual(data["commit_hash"], "04dc013305b713c1eb3ea0117e462aa77099485f")
        self.assertEqual(data["parent"], "62e9ba794c780bb37d5472d79ca8c9d91230892d")
        self.assertEqual(data["total_files"], 39)
        self.assertTrue(data["all_additions"])
        self.assertEqual(data["commit_verification_status"], "transport_commit_verified")

    def test_path_collision_clear(self):
        path = self.v3_dir / "transport_path_collision_v3.json"
        with open(path) as f:
            data = json.load(f)
        self.assertTrue(data["can_cherry_pick"])
        self.assertEqual(len(data["present_different"]), 0)

    def test_mp_evidence_verified(self):
        path = self.v3_dir / "materials_project_evidence_verification_v3.json"
        with open(path) as f:
            data = json.load(f)
        self.assertEqual(data["status"], "mp_evidence_verified")
        self.assertFalse(data["api_key_in_output"])
        # CaSc2TiO6 should have 0 hits
        for q in data["queries"]:
            if q["formula"] == "CaSc2TiO6":
                self.assertEqual(q["count"], 0)

    def test_parent_experiment_scaling_bug(self):
        path = self.v3_dir / "mp_parent_experiment_reaudit_v3.json"
        with open(path) as f:
            data = json.load(f)
        self.assertEqual(data["verdict"], "scaling_bug_confirmed")
        self.assertEqual(data["parent_z"], 2)
        self.assertEqual(data["script_adds_cell_level"]["Ca"], 1)
        self.assertEqual(data["should_add_cell_level"]["Ca"], 2)

    def test_multilingual_partial_verified(self):
        path = self.v3_dir / "multilingual_search_verification_v3.json"
        with open(path) as f:
            data = json.load(f)
        self.assertEqual(data["status"], "multilingual_partial_verified")
        self.assertIn("limitations", data)

    def test_ledger_has_8_corrections(self):
        path = self.v3_dir / "scatti_evidence_ledger_v3.json"
        with open(path) as f:
            data = json.load(f)
        self.assertEqual(len(data["corrections"]), 8)

    def test_corr_008_global_state(self):
        path = self.v3_dir / "scatti_evidence_ledger_v3.json"
        with open(path) as f:
            data = json.load(f)
        corr_008 = [c for c in data["corrections"] if c["correction"] == "CORR-008"]
        self.assertEqual(len(corr_008), 1)
        self.assertEqual(corr_008[0]["final_status"],
                         "cross_host_evidence_reconciled_pre_structure_validation")

    def test_verifier_passed(self):
        path = self.v3_dir / "verifier_results_v3.json"
        with open(path) as f:
            data = json.load(f)
        self.assertEqual(data["overall"], "cross_host_reconciliation_verified",
                         f"Verifier failed: {data.get('failed', 'unknown')} failures")
        self.assertEqual(data["failed"], 0)

    def test_no_scientific_overpromotion(self):
        """Verify no affirmative overpromotion claims in V3 artifacts."""
        overpromotion_terms = [
            "discovered", "stable", "DFT-ready", "synthesizable",
            "breakthrough", "confirmed_structure", "proven",
        ]
        safe_words = {"novelty"}
        negation_prefixes = ["no ", "not ", "not proof of ", "not a "]

        for name in self.required_artifacts:
            path = self.v3_dir / name
            if not path.exists():
                continue
            content = path.read_text().lower()
            for term in overpromotion_terms:
                idx = 0
                while idx < len(content):
                    idx = content.find(term, idx)
                    if idx == -1:
                        break
                    word_start = content.rfind(" ", 0, idx) + 1
                    word_end = content.find(" ", idx)
                    if word_end == -1:
                        word_end = len(content)
                    full_word = content[word_start:word_end].strip(".,;:!?\"'")
                    if full_word in safe_words:
                        idx += len(term)
                        continue
                    start = max(0, idx - 30)
                    preceding = content[start:idx].strip()
                    is_negated = any(preceding.endswith(neg) for neg in negation_prefixes)
                    self.assertTrue(is_negated,
                                    f"Affirmative overpromotion '{term}' found in {name}")
                    idx += len(term)

    def test_report_rendered(self):
        report_path = REPO_ROOT / "docs" / "WESLR_SCATTI_CROSS_HOST_RECONCILIATION_REPORT_V3.md"
        self.assertTrue(report_path.exists())
        content = report_path.read_text()
        self.assertIn("cross_host_evidence_reconciled_pre_structure_validation", content)
        self.assertIn("04dc013305b713c1eb3ea0117e462aa77099485f", content)
        self.assertIn("scaling_bug_confirmed", content)

    def test_no_missing_source_paths(self):
        """Verify all source paths referenced in V3 artifacts exist in the repo."""
        v3_paths = [
            "data/scatti_candidates/materials_project/materials_project_search_results.json",
            "data/scatti_candidates/materials_project/cifs/mp-753401_Sc2TiO5.cif",
            "data/scatti_candidates/materials_project/cifs/mp-4056_CaSc2O4.cif",
            "data/scatti_candidates/materials_project/cifs/mp-753802_Sc2Ti2O7.cif",
            "data/scatti_candidates/materials_project/cifs/mp-780402_Sc2Ti2O7.cif",
            "data/scatti_candidates/scatti_multilingual_search.json",
            "data/scatti_candidates/chgnet_relaxation/SCATTI-LAYERED-001/relaxation_summary.json",
        ]
        for p in v3_paths:
            full_path = REPO_ROOT / p
            self.assertTrue(full_path.exists(), f"Missing source path: {p}")

    def test_implementation_inventory_complete(self):
        path = self.v3_dir / "scatti_implementation_inventory_v3.json"
        with open(path) as f:
            data = json.load(f)
        self.assertGreater(len(data.get("modules", {})), 0)
        self.assertGreater(len(data.get("scripts", {})), 0)
        self.assertGreater(len(data.get("tests", {})), 0)


if __name__ == "__main__":
    unittest.main()
