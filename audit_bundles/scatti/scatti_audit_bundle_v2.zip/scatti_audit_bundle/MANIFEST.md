# SCATTI Audit Bundle v2

Target candidate: CaSc2TiO6 / "scatti"

Purpose:
External audit of current SCATTI computational screening artifacts.

Current scientific status:
- CaSc2TiO6 remains an unvalidated computational candidate.
- No confirmed exact external structure.
- 0 production DFT-ready structures.
- 2 pre-relaxation starting geometries.
- CHGNet relaxation on SCATTI-LAYERED-001 succeeded technically but is classified as ml_relaxed_but_not_qe_ready.
- No Quantum ESPRESSO installed.
- No DFT run.

Important CHGNet result:
- formula preserved: CaSc2TiO6
- max_force after relaxation: 0.596 eV/Å
- fmax target: 0.2 eV/Å
- convergence: not reached, 50 steps hit
- volume collapsed by about 24%
- shortest O-O: 1.483 Å
- Sc-O coordination: 2,2
- Ca-O coordination: 2

Claim boundary:
This bundle is screening evidence only. It does not prove discovery, novelty, stability, synthesis, durability, or experimental validation.
